javac CharacterTokenizer_TokenLevel.java
java CharacterTokenizer_TokenLevel $1 $2
fstcompile --isymbols=ascii.syms --osymbols=ascii.syms $2 input.fst
fstproject --project_output input.fst | fstrmepsilon | fstdeterminize | fstminimize > output.fst
fstprint --isymbols=ascii.syms --osymbols=ascii.syms output.fst > output.txt

