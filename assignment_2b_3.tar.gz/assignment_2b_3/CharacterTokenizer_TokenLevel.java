import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class CharacterTokenizer_TokenLevel {
	private static String inputFile = "C:/Users/Vaishali/NLP/OpenFST/src/com/transducers/assignment1/Input.txt";
	private static String outputFile = "C:/Users/Vaishali/NLP/OpenFST/src/com/transducers/assignment1/OutputTokens1.txt";
	
	private static List<Character> vowels = new ArrayList<Character>(); 
	private static List<Character> specialTokens = new ArrayList<Character>();
	public static void main(String args[]){
		if(args.length == 0 && args.length < 2){
			System.out.println("Please supply input and ouput file names..");
		}
		String inputFile = args[0];
		String outputFile = args[1];
		
		vowels.add(new Character('a'));
		vowels.add(new Character('A'));
		vowels.add(new Character('e'));
		vowels.add(new Character('E'));
		vowels.add(new Character('i'));
		vowels.add(new Character('I'));
		vowels.add(new Character('o'));
		vowels.add(new Character('O'));
		vowels.add(new Character('u'));
		vowels.add(new Character('U'));
		
		specialTokens.add(new Character(','));
		specialTokens.add(new Character('.'));
		specialTokens.add(new Character('?'));
		specialTokens.add(new Character('\"'));
		specialTokens.add(new Character(','));
		specialTokens.add(new Character('!'));
		specialTokens.add(new Character('@'));
		specialTokens.add(new Character('#'));
		specialTokens.add(new Character('$'));
		specialTokens.add(new Character('%'));
		specialTokens.add(new Character('^'));
		specialTokens.add(new Character('&'));
		specialTokens.add(new Character('*'));
		specialTokens.add(new Character(')'));
		specialTokens.add(new Character('('));
		specialTokens.add(new Character('{'));
		specialTokens.add(new Character('}'));
		specialTokens.add(new Character('['));
		specialTokens.add(new Character(']'));
		specialTokens.add(new Character('|'));
		specialTokens.add(new Character(':'));
		specialTokens.add(new Character(';'));
		specialTokens.add(new Character('>'));
		specialTokens.add(new Character('<'));
		specialTokens.add(new Character('`'));
		
		BufferedReader reader = null;
		PrintWriter printWriter = null;
		String line = null;
		try{
			int counter = 0;
			reader = new BufferedReader(new FileReader("./" +  new File(args[0])));
			printWriter = new PrintWriter(new FileWriter("./"  +new File(args[1])));
			while((line = reader.readLine()) != null){
				String[] words = line.split(" ");
				String output = null;
				if(!line .equals("") ){
					for(int j=0; j < words.length; j++){
						char[] tokens = words[j].toCharArray();
						for(int i=0; i < tokens.length ; i++)
						{   
							if((((i != 0) && (i != tokens.length - 1)) 
									&& (vowels.contains(new Character(tokens[i]))))
								&& !((i == tokens.length - 2) 
									&& (specialTokens.contains(new Character(tokens[i+1]))))){
								output = counter + " " 
										+ new Integer(counter + 1).toString() + "\t"
										+ tokens[i] + " "
										+ "<epsilon>";
								printWriter.println(output);
							}
							else{
								output = counter + " " 
										+ new Integer(counter + 1).toString() + "\t"
										+ tokens[i] + " "
										+ tokens[i];
								printWriter.println(output);	
							}
							counter ++;
						}
						output = counter + " " 
								+ new Integer(counter + 1).toString() + " "
								+ "<space>" + " "
								+ "<space>";
						printWriter.println(output);
						counter ++;
					}	
				}
				output = counter + " " 
						+ new Integer(counter + 1).toString() + " "
						+ "<newline>" + " "
						+ "<newline>";
				printWriter.println(output);
			}	
			printWriter.print(new Integer(counter + 1));
		}
		catch(IOException ioe){
			ioe.printStackTrace();
		}
		finally{
			try {
				reader.close();
				printWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}
	}
}
