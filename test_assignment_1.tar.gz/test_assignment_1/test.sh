javac CharacterTokenizer.java
java CharacterTokenizer $1 $2
fstcompile --isymbols=ascii.syms --osymbols=ascii.syms unvowel.txt unvowel.fst
fstcompile --isymbols=ascii.syms --osymbols=ascii.syms $2 input.fst
fstcompose input.fst unvowel.fst | fstproject --project_output | fstrmepsilon | fstprint --isymbols=ascii.syms --osymbols=ascii.syms > output_unvowel.txt

