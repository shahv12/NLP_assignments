import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class CharacterTokenizer {
	
	public static void main(String args[]){
		if(args.length == 0 && args.length < 2){
			System.out.println("Please supply input and ouput file names..");
		}
		BufferedReader reader = null;
		PrintWriter printWriter = null;
		String line = null;
		try{
			int counter = 0;
			reader = new BufferedReader(new FileReader("./" +  new File(args[0])));
			printWriter = new PrintWriter(new FileWriter("./"  +new File(args[1])));
			while((line = reader.readLine()) != null){
				String[] words = line.split(" ");
				String output = null;
				if(!line .equals("") ){
					for(int j=0; j < words.length; j++){
						char[] tokens = words[j].toCharArray();
						for(int i=0; i < tokens.length ; i++)
						{
							output = counter + " " 
											+ new Integer(counter + 1).toString() + "\t"
											+ tokens[i] + " "
											+ tokens[i];
							printWriter.println(output);
							counter ++;
						}
						output = counter + " " 
								+ new Integer(counter + 1).toString() + " "
								+ "<space>" + " "
								+ "<space>";
						printWriter.println(output);
						counter ++;
					}	
				}
				output = counter + " " 
						+ new Integer(counter + 1).toString() + " "
						+ "<newline>" + " "
						+ "<newline>";
				printWriter.println(output);
			}	
			printWriter.print(new Integer(counter + 1));
		}
		catch(IOException ioe){
			ioe.printStackTrace();
		}
		finally{
			try {
				reader.close();
				printWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}
	}
}
